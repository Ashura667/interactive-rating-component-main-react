import "./Notationscale.css";
function Notationscale() {
  return (<div>
    {() => {return "coucou"}}
  </div>);
}

export default Notationscale;
